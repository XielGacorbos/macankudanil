# Telegram Domain Rotator Bot

Bot Telegram untuk manajemen rotator domain brand secara otomatis dengan integrasi Cloudflare dan CPanel.

## 🚀 Fitur Utama

### 1. Auto Deteksi Domain Terblokir
- Deteksi otomatis domain yang terblokir dari pesan monitoring
- Auto rotasi dengan domain cadangan
- Notifikasi real-time ke admin

### 2. Manajemen Link Domain (CRUD)
- Tambah link satuan atau multiple sekaligus
- Status tracking (available/used)
- Validasi duplikat otomatis

### 3. Upload & Extract ZIP ke CPanel
- Upload file ZIP via Telegram
- Auto ekstrak ke public_html
- Cleanup otomatis file ZIP

### 4. Integrasi Cloudflare
- Auto buat subdomain dengan format: `rtp{nomor}.{brand}.rtpxielal.lat`
- DNS management via API
- Auto-increment nomor subdomain

### 5. Monitoring & Alerts
- Alert stok habis
- Log semua aktivitas
- Status monitoring real-time

## 📋 Setup & Instalasi

### 1. Clone Repository
```bash
git clone <repository-url>
cd telegram-domain-rotator-bot
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Konfigurasi Environment
Salin `.env.example` ke `.env` dan isi konfigurasi:

```bash
cp .env.example .env
```

Edit file `.env`:
```env
# Bot Configuration
BOT_TOKEN=your_bot_token_here
ADMINS=123456789,987654321

# Cloudflare Configuration
CLOUDFLARE_API_TOKEN=your_cloudflare_api_token
CLOUDFLARE_ZONE_ID=your_zone_id
CLOUDFLARE_BASE_DOMAIN=rtpxielal.lat
DEFAULT_A_RECORD_IP=1.2.3.4

# CPanel Configuration
CPANEL_HOST=cpanel.example.com
CPANEL_USERNAME=your_cpanel_username
CPANEL_PASSWORD=your_cpanel_password
CPANEL_PORT=2083

# App Configuration
LOG_CHAT_ID=your_log_chat_id
CHECK_INTERVAL=300000
WEBHOOK_URL=https://your-webhook-url.com/blocked
```

### 4. Jalankan Bot
```bash
npm start
```

Untuk development:
```bash
npm run dev
```

## 🤖 Perintah Bot

### Domain Management
- `/tambahlink [brand] [url]` - Tambah 1 link
- `/tambahlinklist [brand]` - Tambah banyak link
- `/listlink [brand]` - Lihat semua link brand
- `/hapuslink [url]` - Hapus domain dari stok
- `/cekstok` - Cek semua stok domain

### DNS Management
- `/buatdns [brand] [nomor]` - Buat DNS manual
- `/autoadd [brand]` - Buat DNS otomatis dengan auto-nomor

### File Management
- `/uploadzip` - Upload ZIP dan extract ke CPanel

### Monitoring
- `/status` - Status sistem
- `/logs` - Lihat log terbaru

## 🏷️ Brand yang Didukung

- RTP MURAH138 (`murah138`)
- RTP MURAHSLOT (`murahslot`)
- RTP TORO168 (`toro168`)
- RTP CATUR4D (`catur4d`)
- RTP MUDAH4D (`mudah4d`)
- RTP PRAGMATIC4D (`pragmatic4d`)
- RTP MURAH4D (`murah4d`)

## 📁 Struktur Project

```
/bot-rotator
├── index.js                 # Entry point
├── handlers/
│   ├── domainHandler.js     # Domain management
│   ├── dnsHandler.js        # DNS management
│   ├── fileUploadHandler.js # File upload handling
│   └── blockedDetector.js   # Blocked domain detection
├── utils/
│   ├── cloudflare.js        # Cloudflare API integration
│   ├── cpanel.js            # CPanel API integration
│   └── storage.js           # Data storage management
├── data/
│   ├── domains.json         # Domain database
│   ├── counters.json        # DNS counters
│   ├── logs.json            # Activity logs
│   └── userStates.json      # User states
├── .env                     # Environment config
├── .env.example             # Environment template
└── package.json
```

## 🔧 API Integrations

### Cloudflare API
- DNS record management
- Zone management
- Cache purging

### CPanel API
- File upload
- ZIP extraction
- Directory management
- Subdomain creation

## 📊 Monitoring

Bot dilengkapi dengan:
- Real-time monitoring domain status
- Auto backup data harian
- Log semua aktivitas
- Alert sistem untuk stok habis
- Cron job untuk maintenance otomatis

## 🛡️ Security

- Multi-admin support
- Input validation
- API token security
- HTTPS enforcement untuk CPanel
- Rate limiting protection

## 🐛 Troubleshooting

### Common Issues

1. **Bot tidak merespon**
   - Cek BOT_TOKEN di .env
   - Pastikan bot sudah di-start dengan `/start`

2. **Cloudflare API error**
   - Verifikasi CLOUDFLARE_API_TOKEN
   - Cek CLOUDFLARE_ZONE_ID

3. **CPanel upload gagal**
   - Cek kredensial CPanel
   - Pastikan CPanel accessible

4. **File permission error**
   - Pastikan directory `data/` writable
   - Cek permission file JSON

## 📝 Changelog

### v1.0.0
- Initial release
- Basic domain management
- Cloudflare integration
- CPanel integration
- Auto rotation system
- Multi-admin support

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

MIT License - see LICENSE file for details

## 📞 Support

Untuk support dan pertanyaan:
- Create issue di GitHub
- Contact admin via Telegram

---

**⚡ Bot Telegram Domain Rotator - Automated Domain Management Solution**