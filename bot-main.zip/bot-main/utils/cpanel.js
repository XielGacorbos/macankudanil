const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

class CpanelAPI {
  
  constructor() {
    this.host = process.env.CPANEL_HOST;
    this.username = process.env.CPANEL_USERNAME;
    this.password = process.env.CPANEL_PASSWORD;
    this.port = process.env.CPANEL_PORT || 2083;
    
    this.baseURL = `https://${this.host}:${this.port}`;
    this.auth = {
      username: this.username,
      password: this.password
    };
  }

  async uploadFile(filePath, fileName) {
    try {
      const formData = new FormData();
      formData.append('file-1', fs.createReadStream(filePath));
      formData.append('dir', '/public_html');

      const response = await axios.post(
        `${this.baseURL}/execute/Fileman/upload_files`,
        formData,
        {
          auth: this.auth,
          headers: {
            ...formData.getHeaders()
          },
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'Upload failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }

  async extractZip(fileName, destination = '/public_html') {
    try {
      const response = await axios.post(
        `${this.baseURL}/execute/Fileman/extract_files`,
        {
          file: `${destination}/${fileName}`,
          destination: destination
        },
        {
          auth: this.auth,
          headers: {
            'Content-Type': 'application/json'
          },
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          files: response.data.data?.files || [],
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'Extract failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }

  async deleteFile(fileName, directory = '/public_html') {
    try {
      const response = await axios.post(
        `${this.baseURL}/execute/Fileman/delete_files`,
        {
          files: [`${directory}/${fileName}`]
        },
        {
          auth: this.auth,
          headers: {
            'Content-Type': 'application/json'
          },
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'Delete failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }

  async createDirectory(directoryName, path = '/public_html') {
    try {
      const response = await axios.post(
        `${this.baseURL}/execute/Fileman/create_directory`,
        {
          name: directoryName,
          path: path
        },
        {
          auth: this.auth,
          headers: {
            'Content-Type': 'application/json'
          },
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'Create directory failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }

  async listFiles(directory = '/public_html') {
    try {
      const response = await axios.get(
        `${this.baseURL}/execute/Fileman/list_files`,
        {
          params: {
            dir: directory
          },
          auth: this.auth,
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          files: response.data.data || [],
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'List files failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }

  async createSubdomain(subdomain, documentRoot = null) {
    try {
      const response = await axios.post(
        `${this.baseURL}/execute/SubDomain/addsubdomain`,
        {
          domain: subdomain,
          rootdomain: process.env.CLOUDFLARE_BASE_DOMAIN,
          dir: documentRoot || `public_html/${subdomain}`
        },
        {
          auth: this.auth,
          headers: {
            'Content-Type': 'application/json'
          },
          httpsAgent: new (require('https')).Agent({
            rejectUnauthorized: false
          })
        }
      );

      if (response.data.status === 1) {
        return {
          success: true,
          data: response.data
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0] || 'Create subdomain failed'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0] || error.message
      };
    }
  }
}

module.exports = new CpanelAPI();