const fs = require('fs');
const path = require('path');

class Storage {
  
  constructor() {
    this.dataDir = './data';
    this.domainsFile = path.join(this.dataDir, 'domains.json');
    this.countersFile = path.join(this.dataDir, 'counters.json');
    this.logsFile = path.join(this.dataDir, 'logs.json');
    this.userStatesFile = path.join(this.dataDir, 'userStates.json');
    
    this.initializeFiles();
  }

  initializeFiles() {
    // Create data directory if it doesn't exist
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    // Initialize domains.json
    if (!fs.existsSync(this.domainsFile)) {
      fs.writeFileSync(this.domainsFile, JSON.stringify({}, null, 2));
    }

    // Initialize counters.json
    if (!fs.existsSync(this.countersFile)) {
      const initialCounters = {
        "murah138": 0,
        "murahslot": 0,
        "toro168": 0,
        "catur4d": 0,
        "mudah4d": 0,
        "pragmatic4d": 0,
        "murah4d": 0
      };
      fs.writeFileSync(this.countersFile, JSON.stringify(initialCounters, null, 2));
    }

    // Initialize logs.json
    if (!fs.existsSync(this.logsFile)) {
      fs.writeFileSync(this.logsFile, JSON.stringify([], null, 2));
    }

    // Initialize userStates.json
    if (!fs.existsSync(this.userStatesFile)) {
      fs.writeFileSync(this.userStatesFile, JSON.stringify({}, null, 2));
    }
  }

  async loadDomains() {
    try {
      const data = fs.readFileSync(this.domainsFile, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading domains:', error);
      return {};
    }
  }

  async saveDomains(domains) {
    try {
      fs.writeFileSync(this.domainsFile, JSON.stringify(domains, null, 2));
      return true;
    } catch (error) {
      console.error('Error saving domains:', error);
      throw error;
    }
  }

  async loadCounters() {
    try {
      const data = fs.readFileSync(this.countersFile, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading counters:', error);
      return {};
    }
  }

  async saveCounters(counters) {
    try {
      fs.writeFileSync(this.countersFile, JSON.stringify(counters, null, 2));
      return true;
    } catch (error) {
      console.error('Error saving counters:', error);
      throw error;
    }
  }

  async loadLogs() {
    try {
      const data = fs.readFileSync(this.logsFile, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading logs:', error);
      return [];
    }
  }

  async addLog(logEntry) {
    try {
      const logs = await this.loadLogs();
      logs.unshift(logEntry); // Add to beginning of array
      
      // Keep only last 1000 logs
      if (logs.length > 1000) {
        logs.splice(1000);
      }
      
      fs.writeFileSync(this.logsFile, JSON.stringify(logs, null, 2));
      return true;
    } catch (error) {
      console.error('Error adding log:', error);
      throw error;
    }
  }

  async getRecentLogs(limit = 50) {
    try {
      const logs = await this.loadLogs();
      return logs.slice(0, limit);
    } catch (error) {
      console.error('Error getting recent logs:', error);
      return [];
    }
  }

  setUserState(chatId, state) {
    try {
      const userStates = JSON.parse(fs.readFileSync(this.userStatesFile, 'utf8'));
      userStates[chatId] = state;
      fs.writeFileSync(this.userStatesFile, JSON.stringify(userStates, null, 2));
    } catch (error) {
      console.error('Error setting user state:', error);
    }
  }

  getUserState(chatId) {
    try {
      const userStates = JSON.parse(fs.readFileSync(this.userStatesFile, 'utf8'));
      return userStates[chatId] || null;
    } catch (error) {
      console.error('Error getting user state:', error);
      return null;
    }
  }

  clearUserState(chatId) {
    try {
      const userStates = JSON.parse(fs.readFileSync(this.userStatesFile, 'utf8'));
      delete userStates[chatId];
      fs.writeFileSync(this.userStatesFile, JSON.stringify(userStates, null, 2));
    } catch (error) {
      console.error('Error clearing user state:', error);
    }
  }

  async backup() {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(this.dataDir, 'backups');
      
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }

      // Backup all data files
      const files = ['domains.json', 'counters.json', 'logs.json'];
      
      for (const file of files) {
        const sourcePath = path.join(this.dataDir, file);
        const backupPath = path.join(backupDir, `${timestamp}-${file}`);
        
        if (fs.existsSync(sourcePath)) {
          fs.copyFileSync(sourcePath, backupPath);
        }
      }

      return {
        success: true,
        backupDir: backupDir,
        timestamp: timestamp
      };

    } catch (error) {
      console.error('Error creating backup:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async cleanOldBackups(daysToKeep = 7) {
    try {
      const backupDir = path.join(this.dataDir, 'backups');
      
      if (!fs.existsSync(backupDir)) {
        return { success: true, cleaned: 0 };
      }

      const files = fs.readdirSync(backupDir);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      let cleaned = 0;

      for (const file of files) {
        const filePath = path.join(backupDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.mtime < cutoffDate) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      }

      return { success: true, cleaned };

    } catch (error) {
      console.error('Error cleaning old backups:', error);
      return { success: false, error: error.message };
    }
  }
}

module.exports = new Storage();