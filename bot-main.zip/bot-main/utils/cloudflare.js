const axios = require('axios');

class CloudflareAPI {
  
  constructor() {
    this.apiToken = process.env.CLOUDFLARE_API_TOKEN;
    this.zoneId = process.env.CLOUDFLARE_ZONE_ID;
    this.baseURL = 'https://api.cloudflare.com/client/v4';
    
    this.headers = {
      'Authorization': `Bearer ${this.apiToken}`,
      'Content-Type': 'application/json'
    };
  }

  async createDNSRecord(name, content, type = 'A', proxied = true, ttl = 1) {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/dns_records`;
      
      const data = {
        type: type,
        name: name,
        content: content,
        ttl: ttl,
        proxied: proxied
      };

      const response = await axios.post(url, data, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true,
          recordId: response.data.result.id,
          data: response.data.result
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }

  async deleteDNSRecord(recordId) {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/dns_records/${recordId}`;
      
      const response = await axios.delete(url, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }

  async listDNSRecords() {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/dns_records`;
      
      const response = await axios.get(url, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true,
          data: response.data.result
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }

  async updateDNSRecord(recordId, data) {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/dns_records/${recordId}`;
      
      const response = await axios.put(url, data, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true,
          data: response.data.result
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }

  async getDNSRecord(recordId) {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/dns_records/${recordId}`;
      
      const response = await axios.get(url, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true,
          data: response.data.result
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }

  async purgeCache(files = []) {
    try {
      const url = `${this.baseURL}/zones/${this.zoneId}/purge_cache`;
      
      const data = files.length > 0 ? { files } : { purge_everything: true };
      
      const response = await axios.post(url, data, { headers: this.headers });
      
      if (response.data.success) {
        return {
          success: true
        };
      } else {
        return {
          success: false,
          error: response.data.errors?.[0]?.message || 'Unknown error'
        };
      }

    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.errors?.[0]?.message || error.message
      };
    }
  }
}

module.exports = new CloudflareAPI();