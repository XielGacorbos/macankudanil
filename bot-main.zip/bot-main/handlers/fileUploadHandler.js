const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');
const cpanelAPI = require('../utils/cpanel');
const storage = require('../utils/storage');
const moment = require('moment');

class FileUploadHandler {

  async handleZipUpload(bot, msg) {
    try {
      const fileId = msg.document.file_id;
      const fileName = msg.document.file_name;
      
      // Validate file type
      if (!fileName.toLowerCase().endsWith('.zip')) {
        throw new Error('File harus berformat ZIP!');
      }

      // Download file from Telegram
      bot.sendMessage(msg.chat.id, '📥 Mengunduh file ZIP...');
      
      const fileInfo = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${fileInfo.file_path}`;
      
      const response = await fetch(fileUrl);
      const buffer = await response.arrayBuffer();
      
      // Save temporarily
      const tempDir = './temp';
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
      }
      
      const tempFilePath = path.join(tempDir, fileName);
      fs.writeFileSync(tempFilePath, Buffer.from(buffer));

      bot.sendMessage(msg.chat.id, '📤 Mengupload ke CPanel...');

      // Upload to CPanel
      const uploadResult = await cpanelAPI.uploadFile(tempFilePath, fileName);
      
      if (!uploadResult.success) {
        throw new Error(`Upload gagal: ${uploadResult.error}`);
      }

      bot.sendMessage(msg.chat.id, '📦 Mengekstrak file ZIP...');

      // Extract ZIP in CPanel
      const extractResult = await cpanelAPI.extractZip(fileName);
      
      if (!extractResult.success) {
        throw new Error(`Ekstrak gagal: ${extractResult.error}`);
      }

      // Clean up ZIP file in CPanel
      await cpanelAPI.deleteFile(fileName);

      // Clean up local temp file
      fs.unlinkSync(tempFilePath);

      // Log activity
      const logEntry = {
        action: 'UPLOAD_ZIP',
        fileName: fileName,
        fileSize: msg.document.file_size,
        extractedFiles: extractResult.files || [],
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        success: true,
        message: `✅ Upload dan ekstrak berhasil!\n\n📁 File: ${fileName}\n📏 Ukuran: ${this.formatFileSize(msg.document.file_size)}\n📦 Diekstrak ke: public_html/\n\n💡 File ZIP sudah dihapus otomatis setelah ekstrak.`
      };

    } catch (error) {
      throw error;
    }
  }

  async validateZipContents(filePath) {
    try {
      const zip = new AdmZip(filePath);
      const entries = zip.getEntries();
      
      let hasHtml = false;
      let totalFiles = entries.length;
      
      entries.forEach(entry => {
        if (entry.entryName.toLowerCase().endsWith('.html') || 
            entry.entryName.toLowerCase().endsWith('.php')) {
          hasHtml = true;
        }
      });

      return {
        valid: hasHtml,
        totalFiles: totalFiles,
        hasWebFiles: hasHtml
      };

    } catch (error) {
      return {
        valid: false,
        error: error.message
      };
    }
  }

  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

module.exports = new FileUploadHandler();