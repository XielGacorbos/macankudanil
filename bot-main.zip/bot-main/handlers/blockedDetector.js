const domainHandler = require('./domainHandler');
const dnsHandler = require('./dnsHandler');
const storage = require('../utils/storage');
const moment = require('moment');

class BlockedDetector {

  async handleBlockedDomain(message) {
    try {
      // Parse blocked domain message
      const domainInfo = this.parseBlockedMessage(message);
      
      if (!domainInfo) {
        throw new Error('Format pesan blocked tidak valid');
      }

      const { domain, description } = domainInfo;
      
      // Extract brand from domain or description
      let brand = this.extractBrandFromDescription(description);
      
      if (!brand) {
        brand = dnsHandler.extractBrandFromDomain(domain);
      }

      if (!brand) {
        throw new Error('Tidak dapat mendeteksi brand dari domain yang diblokir');
      }

      // Mark current domain as used
      await domainHandler.markDomainAsUsed(brand, domain);

      // Get replacement domain
      const replacementDomain = await domainHandler.getAvailableDomain(brand);
      
      if (!replacementDomain) {
        // No replacement available - send alert
        const alertMessage = `
🚨 *DOMAIN TERBLOKIR - STOK HABIS!* 🚨

❌ *Domain Terblokir:* ${domain}
🏷️ *Brand:* ${brand.toUpperCase()}
📅 *Waktu:* ${moment().format('YYYY-MM-DD HH:mm:ss')}

⚠️ *TIDAK ADA STOK PENGGANTI!*

Segera tambahkan stok baru dengan:
\`/tambahlinklist ${brand}\`
        `;

        // Log activity
        const logEntry = {
          action: 'BLOCKED_NO_REPLACEMENT',
          brand: brand,
          blockedDomain: domain,
          timestamp: moment().toISOString()
        };
        await storage.addLog(logEntry);

        return {
          rotated: false,
          message: alertMessage
        };
      }

      // Mark replacement domain as used
      await domainHandler.markDomainAsUsed(brand, replacementDomain.url);

      // Success message
      const successMessage = `
🔄 *ROTASI DOMAIN OTOMATIS* 🔄

❌ *Domain Terblokir:* ${domain}
✅ *Domain Pengganti:* ${replacementDomain.url}
🏷️ *Brand:* ${brand.toUpperCase()}
📅 *Waktu:* ${moment().format('YYYY-MM-DD HH:mm:ss')}

💡 Domain baru sudah aktif dan siap digunakan!

📊 *Status Stok ${brand.toUpperCase()}:*
${await this.getStockStatus(brand)}
      `;

      // Log activity
      const logEntry = {
        action: 'AUTO_ROTATION',
        brand: brand,
        blockedDomain: domain,
        replacementDomain: replacementDomain.url,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        rotated: true,
        message: successMessage,
        oldDomain: domain,
        newDomain: replacementDomain.url,
        brand: brand
      };

    } catch (error) {
      throw error;
    }
  }

  parseBlockedMessage(message) {
    try {
      // Parse message format:
      // TRI (3) (2025/07/25 22:24:48)
      // Domain: https://rtp13.murahrtp5-7.shop/
      // Description: RTP MURAH4D
      // Status: ⛔️⛔️BLOCKED⛔️⛔️

      const lines = message.split('\n');
      let domain = null;
      let description = null;

      for (const line of lines) {
        const trimmedLine = line.trim();
        
        if (trimmedLine.startsWith('Domain:')) {
          domain = trimmedLine.replace('Domain:', '').trim();
        }
        
        if (trimmedLine.startsWith('Description:')) {
          description = trimmedLine.replace('Description:', '').trim();
        }
      }

      if (!domain || !description) {
        return null;
      }

      return { domain, description };

    } catch (error) {
      return null;
    }
  }

  extractBrandFromDescription(description) {
    try {
      // Extract brand from description like "RTP MURAH4D"
      const desc = description.toLowerCase();
      
      const brandMappings = {
        'murah138': 'murah138',
        'murahslot': 'murahslot',
        'toro168': 'toro168',
        'catur4d': 'catur4d',
        'mudah4d': 'mudah4d',
        'pragmatic4d': 'pragmatic4d',
        'murah4d': 'murah4d'
      };

      for (const [key, brand] of Object.entries(brandMappings)) {
        if (desc.includes(key)) {
          return brand;
        }
      }

      return null;

    } catch (error) {
      return null;
    }
  }

  async getStockStatus(brand) {
    try {
      const domains = await storage.loadDomains();
      
      if (!domains[brand]) {
        return 'Brand tidak ditemukan';
      }

      const available = domains[brand].filter(d => d.status === 'available').length;
      const used = domains[brand].filter(d => d.status === 'used').length;

      let status = '';
      if (available === 0) {
        status = '❌ Stok habis!';
      } else if (available <= 3) {
        status = '⚠️ Stok rendah!';
      } else {
        status = '✅ Stok aman';
      }

      return `Tersedia: ${available} | Terpakai: ${used} | ${status}`;

    } catch (error) {
      return 'Error mengecek stok';
    }
  }
}

module.exports = new BlockedDetector();