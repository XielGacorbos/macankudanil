const cloudflareAPI = require('../utils/cloudflare');
const storage = require('../utils/storage');
const moment = require('moment');

class DNSHandler {

  async createManualDNS(brand, number) {
    try {
      const subdomain = `rtp${number}.${brand}`;
      const fullDomain = `${subdomain}.${process.env.CLOUDFLARE_BASE_DOMAIN}`;

      // Create DNS record via Cloudflare
      const dnsResult = await cloudflareAPI.createDNSRecord(subdomain, process.env.DEFAULT_A_RECORD_IP);
      
      if (!dnsResult.success) {
        throw new Error(`Gagal membuat DNS: ${dnsResult.error}`);
      }

      // Update counter
      const counters = await storage.loadCounters();
      if (!counters[brand] || counters[brand] < number) {
        counters[brand] = number;
        await storage.saveCounters(counters);
      }

      // Log activity
      const logEntry = {
        action: 'CREATE_MANUAL_DNS',
        brand: brand,
        number: number,
        domain: fullDomain,
        recordId: dnsResult.recordId,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        success: true,
        message: `✅ DNS berhasil dibuat!\n\n🌐 Domain: ${fullDomain}\n🔢 Nomor: ${number}\n🏷️ Brand: ${brand.toUpperCase()}\n📝 Record ID: ${dnsResult.recordId}\n\n💡 Domain siap digunakan dalam beberapa menit.`
      };

    } catch (error) {
      throw error;
    }
  }

  async createAutoDNS(brand) {
    try {
      const counters = await storage.loadCounters();
      
      // Get next number for this brand
      const nextNumber = (counters[brand] || 0) + 1;
      
      const subdomain = `rtp${nextNumber}.${brand}`;
      const fullDomain = `${subdomain}.${process.env.CLOUDFLARE_BASE_DOMAIN}`;

      // Create DNS record via Cloudflare
      const dnsResult = await cloudflareAPI.createDNSRecord(subdomain, process.env.DEFAULT_A_RECORD_IP);
      
      if (!dnsResult.success) {
        throw new Error(`Gagal membuat DNS: ${dnsResult.error}`);
      }

      // Update counter
      counters[brand] = nextNumber;
      await storage.saveCounters(counters);

      // Log activity
      const logEntry = {
        action: 'CREATE_AUTO_DNS',
        brand: brand,
        number: nextNumber,
        domain: fullDomain,
        recordId: dnsResult.recordId,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        success: true,
        message: `✅ DNS otomatis berhasil dibuat!\n\n🌐 Domain: ${fullDomain}\n🔢 Nomor: ${nextNumber} (auto-generated)\n🏷️ Brand: ${brand.toUpperCase()}\n📝 Record ID: ${dnsResult.recordId}\n\n💡 Domain siap digunakan dalam beberapa menit.\n\n🔄 Gunakan perintah berikut untuk menambahkan ke stok:\n\`/tambahlink ${brand} https://${fullDomain}/\``
      };

    } catch (error) {
      throw error;
    }
  }

  async deleteDNSRecord(recordId) {
    try {
      const result = await cloudflareAPI.deleteDNSRecord(recordId);
      
      if (!result.success) {
        throw new Error(`Gagal menghapus DNS: ${result.error}`);
      }

      return {
        success: true,
        message: '✅ DNS record berhasil dihapus!'
      };

    } catch (error) {
      throw error;
    }
  }

  async listDNSRecords() {
    try {
      const records = await cloudflareAPI.listDNSRecords();
      
      if (!records.success) {
        throw new Error(`Gagal mengambil daftar DNS: ${records.error}`);
      }

      let message = '📋 *DAFTAR DNS RECORDS*\n\n';
      
      const rtpRecords = records.data.filter(record => 
        record.name.includes('rtp') && record.name.endsWith(process.env.CLOUDFLARE_BASE_DOMAIN)
      );

      if (rtpRecords.length === 0) {
        message += 'Tidak ada DNS record RTP yang ditemukan.';
      } else {
        rtpRecords.forEach((record, index) => {
          message += `${index + 1}. *${record.name}*\n`;
          message += `   📍 IP: ${record.content}\n`;
          message += `   🔗 Type: ${record.type}\n`;
          message += `   🛡️ Proxied: ${record.proxied ? 'Ya' : 'Tidak'}\n\n`;
        });
      }

      return {
        success: true,
        message: message
      };

    } catch (error) {
      throw error;
    }
  }

  extractBrandFromDomain(domain) {
    try {
      // Extract brand from domain like: https://rtp3.murah4d123.shop/
      const url = new URL(domain);
      const hostname = url.hostname;
      
      // Pattern: rtp{number}.{brand}.{tld}
      const match = hostname.match(/^rtp\d+\.(.+)\./);
      
      if (match) {
        return match[1];
      }

      return null;
    } catch (error) {
      return null;
    }
  }
}

module.exports = new DNSHandler();