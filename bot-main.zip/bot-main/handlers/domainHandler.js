const storage = require('../utils/storage');
const moment = require('moment');

class DomainHandler {
  
  async addSingleDomain(brand, url) {
    try {
      // Validate URL
      if (!this.isValidUrl(url)) {
        throw new Error('URL tidak valid!');
      }

      const domains = await storage.loadDomains();
      
      if (!domains[brand]) {
        domains[brand] = [];
      }

      // Check for duplicates
      const exists = domains[brand].find(d => d.url === url);
      if (exists) {
        throw new Error('Domain sudah ada dalam database!');
      }

      // Add domain
      const newDomain = {
        url: url,
        status: 'available',
        addedAt: moment().toISOString(),
        usedAt: null
      };

      domains[brand].push(newDomain);
      await storage.saveDomains(domains);

      // Log activity
      const logEntry = {
        action: 'ADD_SINGLE',
        brand: brand,
        url: url,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        success: true,
        message: `✅ Domain berhasil ditambahkan!\n\n🏷️ Brand: ${brand.toUpperCase()}\n🔗 URL: ${url}\n📊 Total stok ${brand}: ${domains[brand].filter(d => d.status === 'available').length}`
      };

    } catch (error) {
      throw error;
    }
  }

  async addMultipleDomains(brand, urls) {
    try {
      const domains = await storage.loadDomains();
      
      if (!domains[brand]) {
        domains[brand] = [];
      }

      let added = 0;
      let duplicates = 0;
      let invalid = 0;

      for (const url of urls) {
        if (!this.isValidUrl(url)) {
          invalid++;
          continue;
        }

        // Check for duplicates
        const exists = domains[brand].find(d => d.url === url);
        if (exists) {
          duplicates++;
          continue;
        }

        // Add domain
        const newDomain = {
          url: url,
          status: 'available',
          addedAt: moment().toISOString(),
          usedAt: null
        };

        domains[brand].push(newDomain);
        added++;
      }

      await storage.saveDomains(domains);

      // Log activity
      const logEntry = {
        action: 'ADD_MULTIPLE',
        brand: brand,
        count: added,
        duplicates: duplicates,
        invalid: invalid,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      let message = `📝 *HASIL TAMBAH LINK*\n\n`;
      message += `🏷️ Brand: ${brand.toUpperCase()}\n`;
      message += `✅ Berhasil ditambah: ${added}\n`;
      if (duplicates > 0) message += `⚠️ Duplikat: ${duplicates}\n`;
      if (invalid > 0) message += `❌ URL tidak valid: ${invalid}\n`;
      message += `\n📊 Total stok tersedia: ${domains[brand].filter(d => d.status === 'available').length}`;

      return {
        success: true,
        message: message
      };

    } catch (error) {
      throw error;
    }
  }

  async listDomains(brand = null) {
    try {
      const domains = await storage.loadDomains();
      
      if (brand && !domains[brand]) {
        return `❌ Brand "${brand.toUpperCase()}" tidak ditemukan!`;
      }

      let message = '📋 *DAFTAR DOMAIN*\n\n';

      if (brand) {
        // Show specific brand
        const brandDomains = domains[brand];
        const available = brandDomains.filter(d => d.status === 'available');
        const used = brandDomains.filter(d => d.status === 'used');

        message += `🏷️ *Brand: ${brand.toUpperCase()}*\n`;
        message += `📊 Tersedia: ${available.length} | Terpakai: ${used.length}\n\n`;

        if (available.length > 0) {
          message += `✅ *TERSEDIA:*\n`;
          available.forEach((domain, index) => {
            message += `${index + 1}. ${domain.url}\n`;
          });
        }

        if (used.length > 0) {
          message += `\n❌ *TERPAKAI:*\n`;
          used.slice(0, 5).forEach((domain, index) => {
            message += `${index + 1}. ${domain.url}\n`;
          });
          if (used.length > 5) {
            message += `... dan ${used.length - 5} lainnya\n`;
          }
        }

      } else {
        // Show all brands summary
        for (const brandName in domains) {
          const brandDomains = domains[brandName];
          const available = brandDomains.filter(d => d.status === 'available').length;
          const used = brandDomains.filter(d => d.status === 'used').length;
          
          message += `🏷️ *${brandName.toUpperCase()}*\n`;
          message += `   ✅ Tersedia: ${available}\n`;
          message += `   ❌ Terpakai: ${used}\n\n`;
        }
      }

      return message;

    } catch (error) {
      throw error;
    }
  }

  async deleteDomain(url) {
    try {
      const domains = await storage.loadDomains();
      let found = false;
      let brandName = '';

      for (const brand in domains) {
        const index = domains[brand].findIndex(d => d.url === url);
        if (index !== -1) {
          domains[brand].splice(index, 1);
          found = true;
          brandName = brand;
          break;
        }
      }

      if (!found) {
        throw new Error('Domain tidak ditemukan!');
      }

      await storage.saveDomains(domains);

      // Log activity
      const logEntry = {
        action: 'DELETE',
        brand: brandName,
        url: url,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return {
        success: true,
        message: `✅ Domain berhasil dihapus!\n\n🏷️ Brand: ${brandName.toUpperCase()}\n🔗 URL: ${url}`
      };

    } catch (error) {
      throw error;
    }
  }

  async checkStock() {
    try {
      const domains = await storage.loadDomains();
      
      let message = '📊 *CEK STOK DOMAIN*\n\n';
      let totalAvailable = 0;
      let totalUsed = 0;
      let lowStockBrands = [];

      for (const brand in domains) {
        const brandDomains = domains[brand];
        const available = brandDomains.filter(d => d.status === 'available').length;
        const used = brandDomains.filter(d => d.status === 'used').length;
        
        totalAvailable += available;
        totalUsed += used;

        let statusIcon = '✅';
        if (available === 0) {
          statusIcon = '❌';
          lowStockBrands.push(brand);
        } else if (available <= 3) {
          statusIcon = '⚠️';
          lowStockBrands.push(brand);
        }

        message += `${statusIcon} *${brand.toUpperCase()}*\n`;
        message += `   📈 Tersedia: ${available}\n`;
        message += `   📉 Terpakai: ${used}\n\n`;
      }

      message += `📋 *RINGKASAN:*\n`;
      message += `• Total Tersedia: ${totalAvailable}\n`;
      message += `• Total Terpakai: ${totalUsed}\n`;

      if (lowStockBrands.length > 0) {
        message += `\n⚠️ *PERINGATAN STOK RENDAH:*\n`;
        lowStockBrands.forEach(brand => {
          message += `• ${brand.toUpperCase()}\n`;
        });
      }

      return message;

    } catch (error) {
      throw error;
    }
  }

  async getAvailableDomain(brand) {
    try {
      const domains = await storage.loadDomains();
      
      if (!domains[brand]) {
        return null;
      }

      const available = domains[brand].filter(d => d.status === 'available');
      
      if (available.length === 0) {
        return null;
      }

      // Return the first available domain
      return available[0];

    } catch (error) {
      throw error;
    }
  }

  async markDomainAsUsed(brand, url) {
    try {
      const domains = await storage.loadDomains();
      
      if (!domains[brand]) {
        throw new Error(`Brand ${brand} tidak ditemukan`);
      }

      const domain = domains[brand].find(d => d.url === url);
      if (!domain) {
        throw new Error('Domain tidak ditemukan');
      }

      domain.status = 'used';
      domain.usedAt = moment().toISOString();

      await storage.saveDomains(domains);

      // Log activity
      const logEntry = {
        action: 'MARK_USED',
        brand: brand,
        url: url,
        timestamp: moment().toISOString()
      };
      await storage.addLog(logEntry);

      return true;

    } catch (error) {
      throw error;
    }
  }

  isValidUrl(string) {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  }
}

module.exports = new DomainHandler();