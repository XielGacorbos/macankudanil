require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const moment = require('moment');

// Import handlers
const domainHandler = require('./handlers/domainHandler');
const dnsHandler = require('./handlers/dnsHandler');
const fileUploadHandler = require('./handlers/fileUploadHandler');
const blockedDetector = require('./handlers/blockedDetector');

// Import utils
const storage = require('./utils/storage');

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

// Admin check middleware
const isAdmin = (chatId) => {
  const adminIds = process.env.ADMINS.split(',').map(id => parseInt(id.trim()));
  return adminIds.includes(chatId);
};

// Welcome message
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak! Anda tidak memiliki izin untuk menggunakan bot ini.');
    return;
  }

  const welcomeMsg = `
🤖 *TELEGRAM DOMAIN ROTATOR BOT*

Bot ini digunakan untuk manajemen rotator domain brand secara otomatis.

📋 *PERINTAH YANG TERSEDIA:*

🔗 *Domain Management:*
• \`/tambahlink [brand] [url]\` - Tambah 1 link
• \`/tambahlinklist [brand]\` - Tambah banyak link (kirim list di pesan berikutnya)
• \`/listlink [brand]\` - Lihat semua link brand
• \`/hapuslink [url]\` - Hapus domain dari stok
• \`/cekstok\` - Cek semua stok domain

🌐 *DNS Management:*
• \`/buatdns [brand] [nomor]\` - Buat DNS manual
• \`/autoadd [brand]\` - Buat DNS otomatis dengan auto-nomor

📁 *File Management:*
• \`/uploadzip\` - Upload ZIP dan extract ke CPanel

📊 *Monitoring:*
• \`/status\` - Status sistem
• \`/logs\` - Lihat log terbaru

Kirim pesan yang mengandung "BLOCKED" untuk auto rotasi domain!
  `;

  bot.sendMessage(chatId, welcomeMsg, { parse_mode: 'Markdown' });
});

// Domain management commands
bot.onText(/\/tambahlink (.+) (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const brand = match[1].toLowerCase();
  const url = match[2];
  
  try {
    const result = await domainHandler.addSingleDomain(brand, url);
    bot.sendMessage(chatId, result.message);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

bot.onText(/\/tambahlinklist (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const brand = match[1].toLowerCase();
  
  bot.sendMessage(chatId, `📝 Kirim daftar link untuk brand *${brand.toUpperCase()}* (satu link per baris):`, { parse_mode: 'Markdown' });
  
  // Store state for next message
  storage.setUserState(chatId, { action: 'waiting_links', brand });
});

bot.onText(/\/listlink (.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const brand = match[1] ? match[1].toLowerCase() : null;
  
  try {
    const result = await domainHandler.listDomains(brand);
    bot.sendMessage(chatId, result, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

bot.onText(/\/hapuslink (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const url = match[1];
  
  try {
    const result = await domainHandler.deleteDomain(url);
    bot.sendMessage(chatId, result.message);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

bot.onText(/\/cekstok/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  try {
    const result = await domainHandler.checkStock();
    bot.sendMessage(chatId, result, { parse_mode: 'Markdown' });
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// DNS management commands
bot.onText(/\/buatdns (.+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const brand = match[1].toLowerCase();
  const number = parseInt(match[2]);
  
  try {
    const result = await dnsHandler.createManualDNS(brand, number);
    bot.sendMessage(chatId, result.message);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

bot.onText(/\/autoadd (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const brand = match[1].toLowerCase();
  
  try {
    const result = await dnsHandler.createAutoDNS(brand);
    bot.sendMessage(chatId, result.message);
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }
});

// File upload command
bot.onText(/\/uploadzip/, (msg) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  bot.sendMessage(chatId, '📁 Kirim file ZIP yang ingin diupload ke CPanel:');
  storage.setUserState(chatId, { action: 'waiting_zip' });
});

// Status command
bot.onText(/\/status/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) {
    bot.sendMessage(chatId, '❌ Akses ditolak!');
    return;
  }

  const domains = await storage.loadDomains();
  const counters = await storage.loadCounters();
  
  let totalAvailable = 0;
  let totalUsed = 0;
  let brandStats = [];
  
  for (const brand in domains) {
    const available = domains[brand].filter(d => d.status === 'available').length;
    const used = domains[brand].filter(d => d.status === 'used').length;
    
    totalAvailable += available;
    totalUsed += used;
    
    brandStats.push(`• ${brand.toUpperCase()}: ${available} tersedia, ${used} terpakai`);
  }

  const statusMsg = `
📊 *STATUS SISTEM*

⏰ *Waktu:* ${moment().format('YYYY-MM-DD HH:mm:ss')}

📈 *Statistik Domain:*
• Total Tersedia: ${totalAvailable}
• Total Terpakai: ${totalUsed}

🏷️ *Per Brand:*
${brandStats.join('\n')}

🔢 *Counter DNS:*
${Object.entries(counters).map(([brand, count]) => `• ${brand.toUpperCase()}: ${count}`).join('\n')}
  `;

  bot.sendMessage(chatId, statusMsg, { parse_mode: 'Markdown' });
});

// Handle document uploads (ZIP files)
bot.on('document', async (msg) => {
  const chatId = msg.chat.id;
  
  if (!isAdmin(chatId)) return;
  
  const userState = storage.getUserState(chatId);
  
  if (userState && userState.action === 'waiting_zip') {
    try {
      const result = await fileUploadHandler.handleZipUpload(bot, msg);
      bot.sendMessage(chatId, result.message);
      storage.clearUserState(chatId);
    } catch (error) {
      bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  }
});

// Handle text messages (for multi-line link input and blocked detection)
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  
  if (!text || text.startsWith('/')) return;
  
  // Check for blocked domain detection
  if (text.includes('BLOCKED') || text.includes('⛔️⛔️BLOCKED⛔️⛔️')) {
    if (isAdmin(chatId)) {
      try {
        const result = await blockedDetector.handleBlockedDomain(text);
        if (result.rotated) {
          // Broadcast to all admins
          const adminIds = process.env.ADMINS.split(',').map(id => parseInt(id.trim()));
          for (const adminId of adminIds) {
            bot.sendMessage(adminId, result.message, { parse_mode: 'Markdown' });
          }
        }
      } catch (error) {
        bot.sendMessage(chatId, `❌ Error dalam rotasi domain: ${error.message}`);
      }
    }
    return;
  }
  
  if (!isAdmin(chatId)) return;
  
  const userState = storage.getUserState(chatId);
  
  if (userState && userState.action === 'waiting_links') {
    try {
      const urls = text.split('\n').map(url => url.trim()).filter(url => url);
      const result = await domainHandler.addMultipleDomains(userState.brand, urls);
      bot.sendMessage(chatId, result.message);
      storage.clearUserState(chatId);
    } catch (error) {
      bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  }
});

// Cron job untuk monitoring domain (setiap 5 menit)
cron.schedule('*/5 * * * *', async () => {
  try {
    // Check for low stock and send alerts
    const domains = await storage.loadDomains();
    const adminIds = process.env.ADMINS.split(',').map(id => parseInt(id.trim()));
    
    for (const brand in domains) {
      const available = domains[brand].filter(d => d.status === 'available').length;
      
      if (available === 0) {
        const alertMsg = `
⚠️ *STOK DOMAIN HABIS* ⚠️

🏷️ *Brand:* ${brand.toUpperCase()}
📅 *Waktu:* ${moment().format('YYYY-MM-DD HH:mm:ss')}

Segera tambahkan stok baru dengan perintah:
\`/tambahlinklist ${brand}\`
        `;
        
        for (const adminId of adminIds) {
          bot.sendMessage(adminId, alertMsg, { parse_mode: 'Markdown' });
        }
      }
    }
  } catch (error) {
    console.error('Error in cron job:', error);
  }
});

// Error handling
bot.on('error', (error) => {
  console.error('Bot error:', error);
});

bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

console.log('🤖 Telegram Domain Rotator Bot started successfully!');
console.log(`📅 Started at: ${moment().format('YYYY-MM-DD HH:mm:ss')}`);