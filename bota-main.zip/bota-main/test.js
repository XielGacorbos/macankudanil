// Simple test file to validate bot functionality
const database = require('./services/database');
const MessageParser = require('./services/messageParser');

console.log('🧪 Running Bot Tests...\n');

// Test 1: Database Operations
console.log('📊 Testing Database Operations...');
try {
    // Test adding stock
    database.addStock('RTP TEST', ['https://test1.com', 'https://test2.com']);
    const stock = database.getBrandStock('RTP TEST');
    console.log('✅ Add Stock Test:', stock.length === 2 ? 'PASSED' : 'FAILED');
    
    // Test getting next domain
    const nextDomain = database.getNextDomain('RTP TEST');
    console.log('✅ Get Next Domain Test:', nextDomain === 'https://test1.com' ? 'PASSED' : 'FAILED');
    
    // Test stock count after removal
    const remainingCount = database.getStockCount('RTP TEST');
    console.log('✅ Auto-remove Test:', remainingCount === 1 ? 'PASSED' : 'FAILED');
    
    // Clean up test data
    database.removeStock('RTP TEST', 'https://test2.com');
    
} catch (error) {
    console.log('❌ Database Test FAILED:', error.message);
}

// Test 2: Message Parser
console.log('\n🔍 Testing Message Parser...');
try {
    const blockedMessage = `
(2025/07/25 22:24:48)
Domain: test.com
Description: RTP MURAHSLOT
Status: ⛔️⛔️BLOCKED⛔️⛔️
    `;
    
    const parsed = MessageParser.parseBlockedDomain(blockedMessage);
    console.log('✅ Blocked Domain Parse Test:', parsed && parsed.brandName === 'RTP MURAHSLOT' ? 'PASSED' : 'FAILED');
    
    const stockCommand = `/addstock RTP TESTBRAND
https://test1.com
https://test2.com`;
    
    const stockParsed = MessageParser.parseAddStockCommand(stockCommand);
    console.log('✅ Add Stock Parse Test:', stockParsed && stockParsed.domains.length === 2 ? 'PASSED' : 'FAILED');
    
    const zipCommand = '/uploadzip RTP CATUR4D rtp9';
    const zipParsed = MessageParser.parseUploadZipCommand(zipCommand);
    console.log('✅ Upload ZIP Parse Test:', zipParsed && zipParsed.subdomainPrefix === 'rtp9' ? 'PASSED' : 'FAILED');
    
} catch (error) {
    console.log('❌ Message Parser Test FAILED:', error.message);
}

// Test 3: Environment Validation
console.log('\n🔧 Testing Environment Configuration...');
require('dotenv').config();

const requiredEnvVars = [
    'BOT_TOKEN',
    'ADMINS',
    'CLOUDFLARE_API_TOKEN',
    'CLOUDFLARE_ZONE_ID',
    'CPANEL_HOST',
    'BASE_DOMAIN'
];

let envTestPassed = true;
requiredEnvVars.forEach(envVar => {
    if (!process.env[envVar]) {
        console.log(`❌ Missing environment variable: ${envVar}`);
        envTestPassed = false;
    }
});

console.log('✅ Environment Test:', envTestPassed ? 'PASSED' : 'FAILED');

// Test 4: File Structure
console.log('\n📁 Testing File Structure...');
const fs = require('fs');
const path = require('path');

const requiredFiles = [
    'bot.js',
    'services/database.js',
    'services/cloudflare.js',
    'services/cpanel.js',
    'services/messageParser.js',
    'bot/handlers.js',
    'data/stok.json'
];

let fileTestPassed = true;
requiredFiles.forEach(file => {
    if (!fs.existsSync(path.join(__dirname, file))) {
        console.log(`❌ Missing file: ${file}`);
        fileTestPassed = false;
    }
});

console.log('✅ File Structure Test:', fileTestPassed ? 'PASSED' : 'FAILED');

console.log('\n🎉 Test Summary:');
console.log('- Database Operations: Ready');
console.log('- Message Parsing: Ready');
console.log('- Environment Config:', envTestPassed ? 'Ready' : 'Needs Setup');
console.log('- File Structure: Ready');

if (envTestPassed) {
    console.log('\n🚀 Bot is ready to run! Use: npm start');
} else {
    console.log('\n⚠️  Please setup your .env file before running the bot');
}