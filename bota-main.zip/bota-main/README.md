# Bot Telegram Manajemen Domain Multi-Brand

Bot Telegram yang powerful untuk mengelola domain multiple brand secara otomatis dengan fitur deteksi domain terblokir, replacement otomatis, dan setup subdomain.

## 🚀 Fitur Utama

### ✅ Multi-Brand Management
- Mengelola 6+ brand secara bersamaan (RTP MURAH138, MURAHSLOT, TORO168, CATUR4D, MUDAH4D, PRAGMATIC4D)
- Database stok domain terpisah per brand
- Management stok yang dinamis

### 🔍 Auto-Detect Domain Terblokir
- Deteksi otomatis pesan domain terblokir dari bot lain
- Parse format pesan dengan pattern khusus
- Identifikasi brand dari description message

### 🔄 Auto-Replace Link
- Replacement domain otomatis saat terdeteksi blocked
- Hapus domain terpakai dari stok
- Alert ke admin jika stok habis

### 📦 Manajemen Stok
- Command `/addstock` untuk menambah domain
- Command `/status` untuk cek stok semua brand
- Command `/listbrands` untuk lihat detail stok
- Command `/clearstock` untuk hapus stok brand

### 📤 Upload & Extract ZIP
- Upload file ZIP via bot
- Auto-create subdomain di CPanel
- Auto-setup DNS di Cloudflare
- Extract dan deploy otomatis

### ☁️ Integrasi API
- **Cloudflare API** untuk DNS management
- **CPanel API** untuk subdomain creation
- **Auto-generated subdomain** dengan pattern: `rtp{number}.{brand}.rtpxielal.lat`

## 📋 Prerequisites

- Node.js 16+ 
- npm
- Telegram Bot Token
- Cloudflare API Token
- CPanel Hosting dengan API access

## 🛠️ Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Setup environment variables:**
```bash
cp .env.example .env
```

Edit `.env` dengan konfigurasi Anda:
```env
# Telegram
BOT_TOKEN=your_telegram_bot_token
ADMINS=123456789,987654321

# Cloudflare
CLOUDFLARE_API_TOKEN=your_token
CLOUDFLARE_ZONE_ID=your_zone_id
CLOUDFLARE_EMAIL=your_email

# CPanel  
CPANEL_HOST=your_host
CPANEL_USERNAME=your_username
CPANEL_PASSWORD=your_password
CPANEL_IP=your_server_ip

# Domain
BASE_DOMAIN=rtpxielal.lat
```

3. **Jalankan bot:**
```bash
npm start
```

## 📱 Commands

### Admin Commands
- `/start` - Welcome message dan info bot
- `/help` - Panduan lengkap penggunaan
- `/status` - Status stok semua brand  
- `/listbrands` - Detail stok per brand
- `/addstock BRAND_NAME` + domain list - Tambah stok domain
- `/clearstock BRAND_NAME` - Hapus semua stok brand
- `/uploadzip BRAND_NAME PREFIX` + ZIP file - Upload & setup subdomain

### Auto-Detection
Bot akan otomatis mendeteksi pesan format:
```
(2025/07/25 22:24:48)
Domain: example.com
Description: RTP MURAHSLOT  
Status: ⛔️⛔️BLOCKED⛔️⛔️
```

Dan otomatis mengganti dengan domain dari stok yang tersedia.

## 📁 Struktur Project

```
├── bot/
│   └── handlers.js          # Handler semua command & logic
├── services/
│   ├── database.js          # JSON database management
│   ├── cloudflare.js        # Cloudflare API integration  
│   ├── cpanel.js            # CPanel API integration
│   └── messageParser.js     # Parse pesan & command
├── data/
│   └── stok.json           # Database stok domain per brand
├── temp/                   # Temporary folder untuk ZIP processing
├── bot.js                  # Main bot file
├── .env                    # Environment configuration
└── README.md
```

## 🔧 Configuration

### Brand Management
Brands yang didukung (dapat ditambah):
- RTP MURAH138
- RTP MURAHSLOT  
- RTP TORO168
- RTP CATUR4D
- RTP MUDAH4D
- RTP PRAGMATIC4D

### Subdomain Pattern
Generated subdomain mengikuti pattern:
`rtp{counter}.{brand_slug}.rtpxielal.lat`

Contoh:
- `rtp1.murahslot.rtpxielal.lat`
- `rtp2.catur4d.rtpxielal.lat`

## 🚨 Error Handling

- ✅ Semua API calls memiliki error handling
- ✅ Bot tidak akan crash jika ada error
- ✅ Log detail untuk debugging
- ✅ Graceful shutdown dengan Ctrl+C
- ✅ Auto-retry untuk failed operations

## 📊 Monitoring

Bot menyediakan:
- Real-time logs di terminal
- Heartbeat setiap 30 detik
- Status tracking semua operations
- Alert broadcast ke semua admin
- Detailed error messages

## 🔒 Security

- Multi-admin support dengan whitelist ID
- Validasi user permissions untuk setiap command
- Input validation untuk semua commands
- Secure API credentials handling

## 📞 Support

Jika ada pertanyaan atau issue, silakan:
1. Check logs di terminal
2. Pastikan semua environment variables sudah benar
3. Test API credentials secara manual
4. Restart bot jika diperlukan

## 🚀 Production Tips

1. **Gunakan Process Manager:**
```bash
npm install -g pm2
pm2 start bot.js --name "domain-bot"
```

2. **Setup Monitoring:**
```bash
pm2 monit
```

3. **Auto-restart:**
```bash  
pm2 startup
pm2 save
```

4. **Backup Database:**
Backup file `data/stok.json` secara berkala.

---

**Happy Domain Managing! 🎉**