const database = require('../services/database');
const cloudflare = require('../services/cloudflare');
const cpanel = require('../services/cpanel');
const MessageParser = require('../services/messageParser');
const fs = require('fs');
const path = require('path');

class BotHandlers {
    constructor(bot) {
        this.bot = bot;
        this.admins = process.env.ADMINS.split(',').map(id => parseInt(id.trim()));
        this.waitingForZip = new Map(); // Store users waiting to upload ZIP
    }

    isAdmin(userId) {
        return this.admins.includes(userId);
    }

    async broadcastToAdmins(message) {
        for (const adminId of this.admins) {
            try {
                await this.bot.sendMessage(adminId, message, { parse_mode: 'Markdown' });
            } catch (error) {
                console.error(`❌ Failed to send message to admin ${adminId}:`, error.message);
            }
        }
    }

    async handleStart(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) {
            await this.bot.sendMessage(chatId, '❌ *Akses ditolak.* Anda tidak memiliki izin untuk menggunakan bot ini.', {
                parse_mode: 'Markdown'
            });
            return;
        }

        const welcomeMessage = `
🤖 *Selamat datang di Bot Manajemen Domain!*

*Fitur yang tersedia:*
📊 \`/status\` - Lihat status stok semua brand
📦 \`/addstock BRAND_NAME\` - Tambah domain ke stok
🗑️ \`/clearstock BRAND_NAME\` - Hapus semua stok brand
📋 \`/listbrands\` - Lihat semua brand yang tersedia
📤 \`/uploadzip BRAND_NAME PREFIX\` - Upload dan setup subdomain
🔄 \`/help\` - Panduan lengkap

*Brand yang didukung:*
• RTP MURAH138
• RTP MURAHSLOT  
• RTP TORO168
• RTP CATUR4D
• RTP MUDAH4D
• RTP PRAGMATIC4D

Bot akan secara otomatis mengganti domain yang terblokir! 📡
        `;

        await this.bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'Markdown' });
    }

    async handleHelp(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const helpMessage = `
📖 *Panduan Lengkap Bot Manajemen Domain*

*🔍 Auto-Detect Domain Terblokir:*
Bot akan otomatis mendeteksi pesan seperti:
\`\`\`
(2025/07/25 22:24:48)
Domain: example.com
Description: RTP MURAHSLOT
Status: ⛔️⛔️BLOCKED⛔️⛔️
\`\`\`

*📦 Menambah Stok Domain:*
\`/addstock RTP MURAHSLOT\`
\`https://rtp1.murahslot.shop/\`
\`https://rtp2.murahslot.shop/\`

*📤 Upload ZIP & Buat Subdomain:*
1. Ketik: \`/uploadzip RTP CATUR4D rtp9\`
2. Kirim file .zip
3. Bot akan membuat: \`rtp9.catur4d.rtpxielal.lat\`

*📊 Monitoring:*
• \`/status\` - Status stok semua brand
• \`/listbrands\` - Daftar brand
• \`/clearstock BRAND_NAME\` - Hapus stok brand

*🚨 Notifikasi Otomatis:*
Bot akan mengirim alert ke semua admin jika stok habis!
        `;

        await this.bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
    }

    async handleStatus(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const brands = database.getAllBrands();
        let statusMessage = '📊 *Status Stok Domain*\n\n';

        if (brands.length === 0) {
            statusMessage += '❌ *Belum ada brand yang terdaftar*';
        } else {
            for (const brand of brands) {
                const count = database.getStockCount(brand);
                const emoji = count > 0 ? '✅' : '❌';
                statusMessage += `${emoji} *${brand}*: ${count} domain\n`;
            }
        }

        statusMessage += `\n🕐 _Update: ${new Date().toLocaleString('id-ID')}_`;

        await this.bot.sendMessage(chatId, statusMessage, { parse_mode: 'Markdown' });
    }

    async handleListBrands(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const brands = database.getAllBrands();
        let message = '📋 *Daftar Brand Terdaftar*\n\n';

        if (brands.length === 0) {
            message += '❌ *Belum ada brand yang terdaftar*';
        } else {
            brands.forEach((brand, index) => {
                const stock = database.getBrandStock(brand);
                message += `${index + 1}. *${brand}*\n`;
                if (stock.length > 0) {
                    message += `   📦 ${stock.length} domain aktif\n`;
                    stock.slice(0, 3).forEach(domain => {
                        message += `   • ${domain}\n`;
                    });
                    if (stock.length > 3) {
                        message += `   • _... dan ${stock.length - 3} domain lainnya_\n`;
                    }
                } else {
                    message += `   ❌ _Stok kosong_\n`;
                }
                message += '\n';
            });
        }

        await this.bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }

    async handleAddStock(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const parsed = MessageParser.parseAddStockCommand(msg.text);

        if (!parsed) {
            await this.bot.sendMessage(chatId, `
❌ *Format salah!*

*Cara yang benar:*
\`/addstock RTP MURAHSLOT\`
\`https://rtp1.murahslot.shop/\`
\`https://rtp2.murahslot.shop/\`

*Pastikan:*
• Brand name valid (contoh: RTP MURAHSLOT)  
• URL lengkap dengan http:// atau https://
            `, { parse_mode: 'Markdown' });
            return;
        }

        const addedCount = database.addStock(parsed.brandName, parsed.domains);

        if (addedCount > 0) {
            await this.bot.sendMessage(chatId, 
                `✅ *Berhasil menambahkan ${addedCount} domain baru untuk brand* **${parsed.brandName}**\n\n` +
                `📊 Total stok sekarang: *${database.getStockCount(parsed.brandName)} domain*`, 
                { parse_mode: 'Markdown' }
            );

            console.log(`✅ Added ${addedCount} domains to ${parsed.brandName} by user ${userId}`);
        } else {
            await this.bot.sendMessage(chatId, 
                `⚠️ *Tidak ada domain baru yang ditambahkan*\n\n` +
                `Semua domain yang Anda kirim sudah ada dalam stok *${parsed.brandName}*`, 
                { parse_mode: 'Markdown' }
            );
        }
    }

    async handleClearStock(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const match = msg.text.match(/^\/clearstock\s+(.+)$/i);
        if (!match) {
            await this.bot.sendMessage(chatId, '❌ *Format salah!* Gunakan: `/clearstock RTP MURAHSLOT`', {
                parse_mode: 'Markdown'
            });
            return;
        }

        const brandName = match[1].trim().toUpperCase();
        const currentStock = database.getBrandStock(brandName);

        if (currentStock.length === 0) {
            await this.bot.sendMessage(chatId, `❌ *Brand ${brandName} tidak memiliki stok domain*`, {
                parse_mode: 'Markdown'  
            });
            return;
        }

        // Clear the stock
        const data = database.readData();
        data[brandName] = [];
        database.writeData(data);

        await this.bot.sendMessage(chatId, 
            `✅ *Berhasil menghapus ${currentStock.length} domain dari brand* **${brandName}**`, 
            { parse_mode: 'Markdown' }
        );

        console.log(`✅ Cleared ${currentStock.length} domains from ${brandName} by user ${userId}`);
    }

    async handleUploadZip(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const parsed = MessageParser.parseUploadZipCommand(msg.text);

        if (!parsed) {
            await this.bot.sendMessage(chatId, `
❌ *Format salah!*

*Cara yang benar:*
\`/uploadzip RTP CATUR4D rtp9\`

Kemudian kirim file .zip
            `, { parse_mode: 'Markdown' });
            return;
        }

        // Store user's upload request
        this.waitingForZip.set(userId, {
            brandName: parsed.brandName,
            subdomainPrefix: parsed.subdomainPrefix,
            chatId: chatId
        });

        await this.bot.sendMessage(chatId, 
            `📤 *Siap menerima file ZIP untuk ${parsed.brandName}*\n\n` +
            `🎯 *Subdomain yang akan dibuat:* \`${parsed.subdomainPrefix}.${parsed.brandName.replace('RTP ', '').toLowerCase()}.rtpxielal.lat\`\n\n` +
            `⏳ _Silakan kirim file .zip sekarang..._`, 
            { parse_mode: 'Markdown' }
        );
    }

    async handleDocument(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        const uploadRequest = this.waitingForZip.get(userId);
        if (!uploadRequest) {
            await this.bot.sendMessage(chatId, '❌ *Tidak ada request upload ZIP aktif.* Gunakan `/uploadzip` terlebih dahulu.', {
                parse_mode: 'Markdown'
            });
            return;
        }

        const document = msg.document;
        if (!document.file_name.endsWith('.zip')) {
            await this.bot.sendMessage(chatId, '❌ *File harus berformat .zip*', {
                parse_mode: 'Markdown'
            });
            return;
        }

        try {
            await this.bot.sendMessage(chatId, '⏳ *Memproses file ZIP...*', { parse_mode: 'Markdown' });

            // Download file
            const fileLink = await this.bot.getFileLink(document.file_id);
            const response = await fetch(fileLink);
            const buffer = Buffer.from(await response.arrayBuffer());

            console.log(`📥 Downloaded ZIP file: ${document.file_name} (${buffer.length} bytes)`);

            // Generate subdomain
            const brandSlug = uploadRequest.brandName.replace('RTP ', '').toLowerCase();
            const fullSubdomain = `${uploadRequest.subdomainPrefix}.${brandSlug}`;

            // Create subdomain in CPanel
            await this.bot.sendMessage(chatId, '🔧 *Membuat subdomain di CPanel...*', { parse_mode: 'Markdown' });
            const subdomainResult = await cpanel.createSubdomain(fullSubdomain);

            if (!subdomainResult.success) {
                await this.bot.sendMessage(chatId, 
                    `❌ *Gagal membuat subdomain*\n\nError: ${subdomainResult.error}`, 
                    { parse_mode: 'Markdown' }
                );
                this.waitingForZip.delete(userId);
                return;
            }

            // Setup DNS di Cloudflare
            await this.bot.sendMessage(chatId, '☁️ *Mengatur DNS di Cloudflare...*', { parse_mode: 'Markdown' });
            const dnsResult = await cloudflare.createDNSRecord(fullSubdomain);

            if (!dnsResult.success) {
                await this.bot.sendMessage(chatId, 
                    `⚠️ *Subdomain dibuat tapi DNS gagal*\n\nError: ${dnsResult.error}`, 
                    { parse_mode: 'Markdown' }
                );
            }

            // Upload and extract ZIP
            await this.bot.sendMessage(chatId, '📦 *Upload dan extract file...*', { parse_mode: 'Markdown' });
            const uploadResult = await cpanel.uploadAndExtractZip(
                buffer, 
                subdomainResult.documentRoot,
                document.file_name
            );

            if (uploadResult.success) {
                const successMessage = `
✅ *Setup berhasil!*

🌐 *Domain:* \`${dnsResult.domain || subdomainResult.subdomain}\`
📁 *Files uploaded:* ${uploadResult.uploadedFiles || 'Unknown'} files
🎯 *Brand:* ${uploadRequest.brandName}

🚀 _Domain akan aktif dalam beberapa menit!_
                `;

                await this.bot.sendMessage(chatId, successMessage, { parse_mode: 'Markdown' });

                // Add to stock automatically
                if (dnsResult.success) {
                    const fullURL = `https://${dnsResult.domain}`;
                    database.addStock(uploadRequest.brandName, [fullURL]);
                    
                    await this.bot.sendMessage(chatId, 
                        `📦 *Domain otomatis ditambahkan ke stok ${uploadRequest.brandName}*`, 
                        { parse_mode: 'Markdown' }
                    );
                }

            } else {
                await this.bot.sendMessage(chatId, 
                    `❌ *Upload gagal*\n\nError: ${uploadResult.error}`, 
                    { parse_mode: 'Markdown' }
                );
            }

        } catch (error) {
            console.error('❌ Upload ZIP Error:', error);
            await this.bot.sendMessage(chatId, 
                `❌ *Terjadi kesalahan saat memproses ZIP*\n\nError: ${error.message}`, 
                { parse_mode: 'Markdown' }
            );
        } finally {
            this.waitingForZip.delete(userId);
        }
    }

    async handleBlockedDomain(msg) {
        try {
            const parsed = MessageParser.parseBlockedDomain(msg.text);

            if (!parsed || !parsed.brandName) {
                return; // Not a blocked domain message
            }

            console.log(`🚨 Detected blocked domain for brand: ${parsed.brandName}`);

            // Get replacement domain
            const replacementDomain = database.getNextDomain(parsed.brandName);

            if (replacementDomain) {
                // Send replacement domain to the same chat
                const replacementMessage = `
🔄 *Domain Replacement untuk ${parsed.brandName}*

✅ *New Domain:* ${replacementDomain}

_Domain otomatis diambil dari stok dan telah dihapus dari list._
                `;

                await this.bot.sendMessage(msg.chat.id, replacementMessage, { parse_mode: 'Markdown' });

                console.log(`✅ Replaced blocked domain with: ${replacementDomain}`);

                // Check if stock is now empty
                if (database.isStockEmpty(parsed.brandName)) {
                    const alertMessage = `
‼️ *STOK HABIS ALERT* ‼️

🚨 Stok domain untuk *${parsed.brandName}* telah habis setelah penggantian terakhir.

📝 Segera tambahkan melalui:
\`/addstock ${parsed.brandName}\`
\`https://new-domain1.shop\`
\`https://new-domain2.shop\`
                    `;

                    await this.broadcastToAdmins(alertMessage);
                }

            } else {
                // No stock available
                const noStockMessage = `
❌ *Stok domain untuk brand ${parsed.brandName} habis*

🔧 _Silakan tambah link baru menggunakan /addstock_
                `;

                await this.bot.sendMessage(msg.chat.id, noStockMessage, { parse_mode: 'Markdown' });

                // Alert all admins
                const adminAlert = `
🚨 *URGENT: Stok Domain Habis* 🚨

*Brand:* ${parsed.brandName}
*Status:* Tidak ada domain pengganti tersedia

📝 *Action Required:*
Tambahkan domain baru dengan:
\`/addstock ${parsed.brandName}\`
\`https://new-domain.shop\`
                `;

                await this.broadcastToAdmins(adminAlert);
            }

        } catch (error) {
            console.error('❌ Error handling blocked domain:', error);
        }
    }

    async handleUnknownCommand(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.isAdmin(userId)) return;

        await this.bot.sendMessage(chatId, `
❓ *Perintah tidak dikenali*

Ketik /help untuk melihat semua perintah yang tersedia.
        `, { parse_mode: 'Markdown' });
    }
}

module.exports = BotHandlers;