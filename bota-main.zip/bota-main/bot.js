const TelegramBot = require('node-telegram-bot-api');
const BotHandlers = require('./bot/handlers');
require('dotenv').config();

// Validate environment variables
if (!process.env.BOT_TOKEN) {
    console.error('❌ BOT_TOKEN tidak ditemukan dalam file .env');
    process.exit(1);
}

if (!process.env.ADMINS) {
    console.error('❌ ADMINS tidak ditemukan dalam file .env');
    process.exit(1);
}

console.log('🤖 Initializing Telegram Bot...');

// Create bot instance dengan polling
const bot = new TelegramBot(process.env.BOT_TOKEN, { 
    polling: {
        interval: 300,
        autoStart: true,
        params: {
            timeout: 10
        }
    }
});

// Initialize handlers
const handlers = new BotHandlers(bot);

console.log('✅ Bot initialized successfully');
console.log('👥 Admins:', process.env.ADMINS);
console.log('🔄 Polling started...');

// Error handling untuk polling
bot.on('polling_error', (error) => {
    console.error('❌ Polling error:', error.message);
});

bot.on('error', (error) => {
    console.error('❌ Bot error:', error.message);
});

// Message handlers
bot.onText(/\/start/, (msg) => {
    console.log(`📨 /start command from user ${msg.from.id}`);
    handlers.handleStart(msg);
});

bot.onText(/\/help/, (msg) => {
    console.log(`📨 /help command from user ${msg.from.id}`);
    handlers.handleHelp(msg);
});

bot.onText(/\/status/, (msg) => {
    console.log(`📨 /status command from user ${msg.from.id}`);
    handlers.handleStatus(msg);
});

bot.onText(/\/listbrands/, (msg) => {
    console.log(`📨 /listbrands command from user ${msg.from.id}`);
    handlers.handleListBrands(msg);
});

bot.onText(/\/addstock/, (msg) => {
    console.log(`📨 /addstock command from user ${msg.from.id}`);
    handlers.handleAddStock(msg);
});

bot.onText(/\/clearstock/, (msg) => {
    console.log(`📨 /clearstock command from user ${msg.from.id}`);  
    handlers.handleClearStock(msg);
});

bot.onText(/\/uploadzip/, (msg) => {
    console.log(`📨 /uploadzip command from user ${msg.from.id}`);
    handlers.handleUploadZip(msg);
});

// Handle documents (ZIP files)
bot.on('document', (msg) => {
    console.log(`📎 Document received from user ${msg.from.id}: ${msg.document.file_name}`);
    handlers.handleDocument(msg);
});

// Handle all text messages for domain blocking detection
bot.on('message', (msg) => {
    // Skip if it's a command
    if (msg.text && msg.text.startsWith('/')) {
        return;
    }

    // Check for blocked domain messages
    if (msg.text && msg.text.includes('⛔️⛔️BLOCKED⛔️⛔️')) {
        console.log(`🚨 Blocked domain detected in message from ${msg.from.id || 'unknown'}`);
        handlers.handleBlockedDomain(msg);
        return;
    }

    // Handle unknown commands
    if (msg.text && msg.text.startsWith('/')) {
        console.log(`❓ Unknown command from user ${msg.from.id}: ${msg.text}`);
        handlers.handleUnknownCommand(msg);
    }
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down bot...');
    bot.stopPolling();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Received SIGTERM, shutting down bot...');
    bot.stopPolling();
    process.exit(0);
});

// Keep process alive and show status
console.log('🟢 Bot is running and listening for messages...');
console.log('Press Ctrl+C to stop the bot');

// Optional: Ping every 30 seconds to show bot is alive
setInterval(() => {
    console.log(`💓 Bot heartbeat - ${new Date().toLocaleTimeString('id-ID')}`);
}, 30000);

module.exports = bot;