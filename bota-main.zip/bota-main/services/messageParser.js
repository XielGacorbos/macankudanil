class MessageParser {
    static parseBlockedDomain(message) {
        try {
            // Pattern untuk mendeteksi pesan domain terblokir
            const blockedPattern = /Status:\s*⛔️⛔️BLOCKED⛔️⛔️/i;
            const descriptionPattern = /Description:\s*(.*)/i;
            const domainPattern = /Domain:\s*(.*)/i;

            if (!blockedPattern.test(message)) {
                return null;
            }

            const descriptionMatch = message.match(descriptionPattern);
            const domainMatch = message.match(domainPattern);

            if (!descriptionMatch) {
                return null;
            }

            const description = descriptionMatch[1].trim();
            const domain = domainMatch ? domainMatch[1].trim() : '';

            // Ekstrak brand name dari description
            const brandMatch = description.match(/RTP\s+([A-Z0-9]+)/i);
            let brandName = null;

            if (brandMatch) {
                brandName = `RTP ${brandMatch[1].toUpperCase()}`;
            }

            return {
                isBlocked: true,
                brandName,
                description,
                domain,
                rawMessage: message
            };
        } catch (error) {
            console.error('❌ Error parsing blocked domain message:', error);
            return null;
        }
    }

    static extractBrandFromDescription(description) {
        const patterns = [
            /RTP\s+(MURAH138)/i,
            /RTP\s+(MURAHSLOT)/i,
            /RTP\s+(TORO168)/i,
            /RTP\s+(CATUR4D)/i,
            /RTP\s+(MUDAH4D)/i,
            /RTP\s+(PRAGMATIC4D)/i
        ];

        for (const pattern of patterns) {
            const match = description.match(pattern);
            if (match) {
                return `RTP ${match[1].toUpperCase()}`;
            }
        }

        return null;
    }

    static validateDomainURL(url) {
        try {
            const urlObj = new URL(url);
            return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
        } catch (error) {
            return false;
        }
    }

    static parseAddStockCommand(message) {
        try {
            const lines = message.split('\n').map(line => line.trim()).filter(line => line);
            
            if (lines.length < 2) {
                return null;
            }

            const commandLine = lines[0];
            const commandMatch = commandLine.match(/^\/addstock\s+(.+)$/i);
            
            if (!commandMatch) {
                return null;
            }

            const brandName = commandMatch[1].trim().toUpperCase();
            const domains = lines.slice(1).filter(line => this.validateDomainURL(line));

            if (domains.length === 0) {
                return null;
            }

            return {
                brandName,
                domains,
                validDomains: domains.length,
                totalLines: lines.length - 1
            };
        } catch (error) {
            console.error('❌ Error parsing add stock command:', error);
            return null;
        }
    }

    static parseUploadZipCommand(message) {
        try {
            const match = message.match(/^\/uploadzip\s+(.+?)\s+(.+)$/i);
            
            if (!match) {
                return null;
            }

            const brandName = match[1].trim().toUpperCase();
            const subdomainPrefix = match[2].trim().toLowerCase();

            return {
                brandName,
                subdomainPrefix,
                isValid: true
            };
        } catch (error) {
            console.error('❌ Error parsing upload zip command:', error);
            return null;
        }
    }
}

module.exports = MessageParser;