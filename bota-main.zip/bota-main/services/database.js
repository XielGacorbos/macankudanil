const fs = require('fs');
const path = require('path');

class Database {
    constructor() {
        this.filePath = path.join(__dirname, '../data/stok.json');
        this.ensureFileExists();
    }

    ensureFileExists() {
        if (!fs.existsSync(this.filePath)) {
            const initialData = {};
            fs.writeFileSync(this.filePath, JSON.stringify(initialData, null, 2));
        }
    }

    readData() {
        try {
            const data = fs.readFileSync(this.filePath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('❌ Error reading database:', error);
            return {};
        }
    }

    writeData(data) {
        try {
            fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2));
            return true;
        } catch (error) {
            console.error('❌ Error writing database:', error);
            return false;
        }
    }

    getBrandStock(brandName) {
        const data = this.readData();
        return data[brandName] || [];
    }

    addStock(brandName, domains) {
        const data = this.readData();
        if (!data[brandName]) {
            data[brandName] = [];
        }
        
        // Filter domain yang belum ada
        const newDomains = domains.filter(domain => !data[brandName].includes(domain));
        data[brandName].push(...newDomains);
        
        this.writeData(data);
        return newDomains.length;
    }

    removeStock(brandName, domain) {
        const data = this.readData();
        if (data[brandName]) {
            const index = data[brandName].indexOf(domain);
            if (index > -1) {
                data[brandName].splice(index, 1);
                this.writeData(data);
                return true;
            }
        }
        return false;
    }

    getNextDomain(brandName) {
        const stock = this.getBrandStock(brandName);
        if (stock.length > 0) {
            const domain = stock[0];
            this.removeStock(brandName, domain);
            return domain;
        }
        return null;
    }

    getAllBrands() {
        const data = this.readData();
        return Object.keys(data);
    }

    getStockCount(brandName) {
        const stock = this.getBrandStock(brandName);
        return stock.length;
    }

    isStockEmpty(brandName) {
        return this.getStockCount(brandName) === 0;
    }
}

module.exports = new Database();