const axios = require('axios');
require('dotenv').config();

class CloudflareService {
    constructor() {
        this.apiToken = process.env.CLOUDFLARE_API_TOKEN;
        this.zoneId = process.env.CLOUDFLARE_ZONE_ID;
        this.email = process.env.CLOUDFLARE_EMAIL;
        this.serverIP = process.env.CPANEL_IP;
        this.baseDomain = process.env.BASE_DOMAIN;
        
        this.headers = {
            'Authorization': `Bearer ${this.apiToken}`,
            'Content-Type': 'application/json'
        };
    }

    async createDNSRecord(subdomain) {
        try {
            const fullDomain = `${subdomain}.${this.baseDomain}`;
            
            const response = await axios.post(
                `https://api.cloudflare.com/client/v4/zones/${this.zoneId}/dns_records`,
                {
                    type: 'A',
                    name: subdomain,
                    content: this.serverIP,
                    ttl: 1, // Auto TTL
                    proxied: false
                },
                { headers: this.headers }
            );

            if (response.data.success) {
                console.log(`✅ DNS Record created: ${fullDomain} -> ${this.serverIP}`);
                return {
                    success: true,
                    domain: fullDomain,
                    recordId: response.data.result.id
                };
            } else {
                console.error('❌ Cloudflare API Error:', response.data.errors);
                return {
                    success: false,
                    error: response.data.errors[0]?.message || 'Unknown error'
                };
            }
        } catch (error) {
            console.error('❌ Cloudflare Service Error:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async deleteDNSRecord(recordId) {
        try {
            const response = await axios.delete(
                `https://api.cloudflare.com/client/v4/zones/${this.zoneId}/dns_records/${recordId}`,
                { headers: this.headers }
            );

            return response.data.success;
        } catch (error) {
            console.error('❌ Error deleting DNS record:', error.message);
            return false;
        }
    }

    async listDNSRecords() {
        try {
            const response = await axios.get(
                `https://api.cloudflare.com/client/v4/zones/${this.zoneId}/dns_records`,
                { headers: this.headers }
            );

            if (response.data.success) {
                return response.data.result;
            } else {
                console.error('❌ Error listing DNS records:', response.data.errors);
                return [];
            }
        } catch (error) {
            console.error('❌ Cloudflare Service Error:', error.message);
            return [];
        }
    }

    generateSubdomain(brand, counter) {
        // Konversi brand ke format subdomain
        const brandSlug = brand
            .replace('RTP ', '')
            .toLowerCase()
            .replace(/[^a-z0-9]/g, '');
        
        return `rtp${counter}.${brandSlug}`;
    }
}

module.exports = new CloudflareService();