const axios = require('axios');
const FormData = require('form-data');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

class CpanelService {
    constructor() {
        this.host = process.env.CPANEL_HOST;
        this.username = process.env.CPANEL_USERNAME;
        this.password = process.env.CPANEL_PASSWORD;
        this.baseURL = `https://${this.host}:2083`;
        
        // Setup basic auth
        this.auth = {
            username: this.username,
            password: this.password
        };
    }

    async createSubdomain(subdomain, documentRoot = null) {
        try {
            const docRoot = documentRoot || `public_html/${subdomain}`;
            
            const response = await axios.get(
                `${this.baseURL}/execute/SubDomain/addsubdomain`,
                {
                    params: {
                        domain: subdomain,
                        rootdomain: process.env.BASE_DOMAIN,
                        dir: docRoot
                    },
                    auth: this.auth,
                    timeout: 30000
                }
            );

            if (response.data.status === 1) {
                console.log(`✅ Subdomain created: ${subdomain}.${process.env.BASE_DOMAIN}`);
                return {
                    success: true,
                    subdomain: `${subdomain}.${process.env.BASE_DOMAIN}`,
                    documentRoot: docRoot
                };
            } else {
                console.error('❌ CPanel Subdomain Error:', response.data);
                return {
                    success: false,
                    error: response.data.errors?.[0] || 'Failed to create subdomain'
                };
            }
        } catch (error) {
            console.error('❌ CPanel Service Error:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async uploadAndExtractZip(zipBuffer, destinationPath, fileName) {
        try {
            const tempDir = path.join(__dirname, '../temp');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }

            const tempZipPath = path.join(tempDir, fileName);
            fs.writeFileSync(tempZipPath, zipBuffer);

            // Extract ZIP
            const zip = new AdmZip(tempZipPath);
            const extractPath = path.join(tempDir, 'extracted');
            zip.extractAllTo(extractPath, true);

            // Upload files via CPanel File Manager API
            const uploadResult = await this.uploadDirectory(extractPath, destinationPath);

            // Cleanup
            fs.rmSync(tempDir, { recursive: true, force: true });

            return uploadResult;
        } catch (error) {
            console.error('❌ Upload and Extract Error:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async uploadDirectory(localPath, remotePath) {
        try {
            // Simple implementation - you might need to implement recursive upload
            const files = fs.readdirSync(localPath);
            let uploadedCount = 0;

            for (const file of files) {
                const filePath = path.join(localPath, file);
                const stat = fs.statSync(filePath);

                if (stat.isFile()) {
                    const success = await this.uploadFile(filePath, `${remotePath}/${file}`);
                    if (success) uploadedCount++;
                } else if (stat.isDirectory()) {
                    // Recursive upload for directories
                    await this.createDirectory(`${remotePath}/${file}`);
                    const result = await this.uploadDirectory(filePath, `${remotePath}/${file}`);
                    uploadedCount += result.uploadedFiles || 0;
                }
            }

            return {
                success: true,
                uploadedFiles: uploadedCount,
                message: `Uploaded ${uploadedCount} files successfully`
            };
        } catch (error) {
            console.error('❌ Directory Upload Error:', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async uploadFile(localFilePath, remotePath) {
        try {
            const formData = new FormData();
            formData.append('file', fs.createReadStream(localFilePath));
            formData.append('dir', path.dirname(remotePath));

            const response = await axios.post(
                `${this.baseURL}/execute/Fileman/upload_files`,
                formData,
                {
                    auth: this.auth,
                    headers: formData.getHeaders(),
                    timeout: 60000
                }
            );

            return response.data.status === 1;
        } catch (error) {
            console.error('❌ File Upload Error:', error.message);
            return false;
        }
    }

    async createDirectory(remotePath) {
        try {
            const response = await axios.get(
                `${this.baseURL}/execute/Fileman/mkdir`,
                {
                    params: {
                        name: path.basename(remotePath),
                        path: path.dirname(remotePath)
                    },
                    auth: this.auth
                }
            );

            return response.data.status === 1;
        } catch (error) {
            console.error('❌ Directory Creation Error:', error.message);
            return false;
        }
    }

    async listFiles(remotePath) {
        try {
            const response = await axios.get(
                `${this.baseURL}/execute/Fileman/list_files`,
                {
                    params: {
                        dir: remotePath
                    },
                    auth: this.auth
                }
            );

            if (response.data.status === 1) {
                return response.data.data;
            } else {
                return [];
            }
        } catch (error) {
            console.error('❌ List Files Error:', error.message);
            return [];
        }
    }
}

module.exports = new CpanelService();